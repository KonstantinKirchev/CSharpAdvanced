﻿using System;

class MethodExample
{
    static void PrintLogo()
    {
        Console.WriteLine("Software University Foundation");
        Console.WriteLine("www.softuni.bg");
    }

    static void Main()
    {
        PrintLogo();
    }
}
